"""Synthetic-data check of the Grand St Bernard pipeline (STB_PROTOCOL.md, section 8). Uses only
generated data in the SensorScope file format; no real measurement. Run in an empty directory that
holds the frozen code; it creates synth_main/, synth_tiny/ and synth_stats/ and asserts the rules of
the protocol. Usage: python3 stb_synthetic_check.py"""
import os, sys, json, glob, shutil, zipfile, subprocess, numpy as np
HERE = os.path.abspath(os.path.dirname(__file__))
CODE = ["stb_prepare.py", "stb_run.py", "stb_stats.py", "segeval.py", "frozen_benchmark.py", "fastfwd.py",
        "dual_prediction_fix.py", "platform_energy.py", "gap8_lstm_energy.py", "ms_numbers.json"]
T0 = 1190000000.0            # 2007-09-17 UTC
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")

def row(st, t, v, n=17):
    f = [str(st), "2007", "9", "1", "0", "0", "0", f"{t:.0f}", v] + ["1"] * (n - 9); return " ".join(f)

def station(rng, st, days, dt0, start=0.0):
    n = int(days * 86400 / dt0); dt = dt0 + rng.normal(0, 2, n)
    dt[rng.random(n) < 0.03] *= 4                     # short gaps
    dt[rng.random(n) < 0.002] *= 40                   # long gaps (segment cuts)
    t = T0 + start + np.cumsum(dt); v = 5 + 3 * np.sin(t / 86400 * 2 * np.pi) + np.cumsum(rng.normal(0, 0.02, n))
    return t, v

def make_main(path):
    rng = np.random.default_rng(7); z = zipfile.ZipFile(path, "w"); z.writestr("stbernard-meteo-def.txt", "synthetic")
    for st, (days, dt0, start) in {2: (15, 120, 0), 3: (15, 120, 0), 4: (15, 120, 0), 5: (15, 120, 0),
                                   6: (15, 300, 0), 7: (3, 120, 0), 8: (15, 120, 0), 9: (15, 120, 0), 10: (12, 120, 3 * 86400)}.items():
        t, v = station(rng, st, days, dt0, start)
        if st == 9: keep = rng.random(len(t)) < 0.3; t, v = t[keep], v[keep]          # sparse: excluded
        out = (t >= T0 + 9 * 86400) & (t < T0 + 10.2 * 86400); t, v = t[~out], v[~out]   # outage of all stations over a whole UTC day
        L = [f"Station Year Month Day Hour Minute Second Time Temp"]                      # header line
        for i, (ti, vi) in enumerate(zip(t, v)):
            val = f"{vi:.3f}"
            if i % 997 == 5: val = "999"                                                  # implausible
            if i % 1499 == 7: val = "-60"
            if i % 2003 == 9: val = "nan"
            L.append(row(st, ti, val))
        L.append(row(st, t[100], f"{v[100]+0.2:.3f}"))                                     # duplicate timestamp
        L.append("2 2007"); L.append(row(st, t[50], f"{v[50]:.3f}", n=18))                # short row; 18 fields
        if st == 5:                                                                        # isolated short segment in the test span
            gap = (t > T0 + 12 * 86400) & (t < T0 + 12.5 * 86400)
            drop = np.r_[False, gap, np.zeros(len(L) - 1 - len(gap), bool)]
            L = [l for l, g in zip(L, drop) if not g]
            tb = T0 + 12.25 * 86400 + np.arange(5) * 120; L += [row(st, x, "4.000") for x in tb]
        L.append(row(st, 3600.0, "4.0"))                                                   # every station: a stray reading on 1 Jan 1970
        L.append(row(st, t[200] * 1000, "4.0"))                                             # a timestamp in milliseconds
        if st == 3: L[3000:3000] = [row(st, x - 2 * 86400, "4.0") for x in t[2990:3010]]   # clock reset: 20 readings two days back
        if st == 4: body = L[1:]; rng.shuffle(body); L = L[:1] + body                     # a file not in time order
        if st == 8: L.append(row(st, t[-1] + 25 * 86400, "4.0"))                            # one more stray, 25 days after the end
        if st == 10: L.append(row(st, T0 + 0.5 * 86400, "4.0"))                             # one stray reading before its real start
        z.writestr(f"stbernard-meteo-{st}.txt", "\r\n".join(L) + "\r\n")
    z.close()

def make_tiny(path):
    rng = np.random.default_rng(3); z = zipfile.ZipFile(path, "w")
    for st in (2, 3):
        t, v = station(rng, st, 0.5, 120); z.writestr(f"stbernard-meteo-{st}.txt", "\n".join(row(st, a, f"{b:.3f}") for a, b in zip(t, v)))
    z.close()

def setup(d):
    shutil.rmtree(d, ignore_errors=True); os.makedirs(d)
    for f in CODE: shutil.copy(os.path.join(HERE, f), d)

def run(d, *args):
    r = subprocess.run([sys.executable, *args], cwd=d, env=ENV, capture_output=True, text=True)
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-3000:]
    return r.stdout

def check_main():
    d = "synth_main"; setup(d); make_main(os.path.join(d, "stbernard-meteo.zip"))
    run(d, "stb_prepare.py", "stbernard-meteo.zip")
    M = json.load(open(f"{d}/stb_meta.json"))
    assert M["stations_kept"] == [2, 3, 4, 5, 7, 8, 10], M["stations_kept"]               # slower (300 s) and sparse stations excluded; stray reading does not exclude 10
    assert M["nominal_interval_s"] == 120.0
    assert M["parse"]["8"]["outside_period"] == 1 and M["parse"]["2"]["outside_time_window"] == 2  # 1970 and millisecond timestamps dropped; late stray outside the period
    assert M["parse"]["3"]["backward_jumps"] == 21 and not M["parse"]["3"]["not_time_ordered"]       # clock reset (20) and the appended repeat dropped
    assert M["parse"]["4"]["not_time_ordered"] and M["parse"]["4"]["backward_jumps"] == 0             # unordered file: rule not applied, only sorting
    assert M["period_utc"][0].startswith("2007-09-17") and M["period_epoch_s"][1] - M["period_epoch_s"][0] >= 14 * 86400   # the outage day is bridged
    assert M["manifest_stations_absent"] == [s for s in [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 20, 25, 28, 29, 31, 32] if s > 10]
    for st in ("2", "5"): assert M["parse"][st]["malformed"] >= 4 and M["parse"][st]["out_of_range"] >= 2   # header, short row, 18-field row and 'nan' dropped
    # the repeated reading appended at the end of each file lies far back in file order: dropped by the clock-reset rule,
    # except in the unordered file, where it is merged as a duplicate timestamp
    assert M["parse"]["2"]["backward_jumps"] == 1 and M["parse"]["4"]["duplicates_merged"] == 1
    P0, b1, b2, P1 = M["boundaries_epoch_s"]
    assert abs((b1 - P0) / (P1 - P0) - 0.5) < 1e-12 and abs((b2 - P0) / (P1 - P0) - 0.7) < 1e-12
    assert M["evaluable"] == {"obs": True, "fill": True}
    assert M["preparations"]["obs"]["test"]["per_station"]["7"]["readings"] == 0          # station absent from test
    import pickle
    for prep in ("obs", "fill"):
        S = pickle.load(open(f"{d}/stb_segments_{prep}.pkl", "rb"))
        lim = {"train": (P0, b1), "val": (b1, b2), "test": (b2, P1 + 1e-6)}
        for s in S:
            lo, hi = lim[s["span"]]; Ds = M["nominal_interval_s"]
            if prep == "obs": assert s["bins"].min() >= lo and s["bins"].max() < hi        # no segment crosses a boundary
            assert np.all(np.diff(s["bins"]) <= 10 * Ds + 1e-9)                            # gaps inside a segment are short
            if prep == "fill": assert not s["filled"][0] and not s["filled"][-1]           # interpolation only between observed bins
        assert M["preparations"][prep]["test"]["short_segments"] >= 1                     # the isolated 5-reading segment
    # evaluator on segments equals the matrix evaluator on each long segment (persistence)
    sys.path.insert(0, d); import segeval as se, frozen_benchmark as fb
    S = [s for s in pickle.load(open(f"{d}/stb_segments_obs.pkl", "rb")) if s["span"] == "test"]
    for f in (None, fb.make_ar(4), fb.make_expsm(0.5)):
        a = se.seg_dps([s["values"] for s in S], f, 0.1, record=True)
        for j, s in enumerate(S):                                                          # segment by segment
            if len(s["values"]) <= 12: assert a["sent"][j].all(); continue
            b = fb.dps(s["values"], f, tau=0.1, look_back=12, train_frac=1e-6, unit=1.0)
            assert int(a["sent"][j][12:].sum()) == b["n_tx"]
        assert a["n_init_reports"] == sum(min(len(s["values"]), 12) for s in S)
    run(d, "stb_run.py", "obs", "cheap"); run(d, "stb_run.py", "fill", "cheap")
    out = run(d, "stb_run.py", "obs", "lightweight", "0", "1")
    r = json.load(open(f"{d}/runs/stb_obs_lightweight_s0.json")); assert r["status"] == "ok" and r["receiver_verified"] and r["sender_receiver_identical"]
    # retry rule: seed 1 fails once (then ok), seed 2 fails twice (recorded as failed), seed 3 still runs
    code = ("import stb_run, json\nn={}\nreal=stb_run.one_seed\n"
            "def fake(prep,D,kind,sd,X,Y):\n    n[sd]=n.get(sd,0)+1\n    if sd==1 and n[sd]==1: raise RuntimeError('x')\n    if sd==2: raise RuntimeError('y')\n"
            "    return dict(status='ok',predictor=kind,seed=int(sd),selected_epoch=25,val_rho=0.5,test_rho=0.5,receiver_verified=True,secs=0)\n"
            "stb_run.one_seed=fake\nD=stb_run.load('obs')\nstb_run.learned('obs',D,'cnn_lstm',range(1,4))\n")
    r = subprocess.run([sys.executable, "-c", code], cwd=d, env=ENV, capture_output=True, text=True); assert r.returncode == 0, r.stderr[-2000:]
    R = {s: json.load(open(f"{d}/runs/stb_obs_cnn_lstm_s{s}.json")) for s in (1, 2, 3)}
    assert R[1]["status"] == "ok" and R[1]["attempts"] == 2 and R[2]["status"] == "failed" and R[3]["status"] == "ok"
    # a process that dies (not an exception): the driver starts it again; after two deaths nothing is written,
    # the next seed still runs, and stb_stats.py lists the seed as missing
    die = ("import stb_run, os\ndef fake(prep,D,kind,sd,X,Y):\n    os._exit(137)\n"
           "stb_run.one_seed=fake\nD=stb_run.load('obs')\nstb_run.learned('obs',D,'cnn_lstm',range(4,5))\n")
    for _ in range(2): subprocess.run([sys.executable, "-c", die], cwd=d, env=ENV)
    assert open(f"{d}/runs/stb_obs_cnn_lstm_s4.json.attempts").read() == "2" and not os.path.exists(f"{d}/runs/stb_obs_cnn_lstm_s4.json")
    r = subprocess.run([sys.executable, "-c", code.replace("range(1,4)", "range(5,6)")], cwd=d, env=ENV, capture_output=True, text=True); assert r.returncode == 0
    assert json.load(open(f"{d}/runs/stb_obs_cnn_lstm_s5.json"))["status"] == "ok"
    return d

def check_tiny():
    d = "synth_tiny"; setup(d); make_tiny(os.path.join(d, "stbernard-meteo.zip"))
    run(d, "stb_prepare.py", "stbernard-meteo.zip")
    M = json.load(open(f"{d}/stb_meta.json")); assert M["evaluable"] == {"obs": False, "fill": False}, M["not_evaluable_reason"]
    out = run(d, "stb_run.py", "obs", "cheap"); assert "not evaluable" in out
    run(d, "stb_stats.py"); S = json.load(open(f"{d}/stb_summary.json")); assert S["primary_obs"] == "not evaluable"

def check_stats(src):
    d = "synth_stats"; shutil.rmtree(d, ignore_errors=True); shutil.copytree(src, d)
    for f in glob.glob(f"{d}/runs/*.json"): os.remove(f)
    I = np.load(f"{d}/cells/stb_obs_index.npz"); n = len(I["mote"])
    C = json.load(open(f"{d}/stb_obs_cheap.json")); rr = C["test"][C["selected"]]["rho"]
    def fab(m, rhos, valid=None):
        for sd, rho in enumerate(rhos):
            json.dump(dict(status="ok", predictor=m, seed=sd, test_rho=rho, test_n_steps=1000, test_n_init_reports=10, test_mean_err=0.01,
                           test_rmse=0.02, test_max_err=0.1, receiver_verified=True if valid is None else valid[sd]),
                      open(f"{d}/runs/stb_obs_{m}_s{sd}.json", "w"))
            np.savez_compressed(f"{d}/cells/stb_obs_{m}_s{sd}.npz", sent=np.zeros(n, bool), err=np.zeros(n))
    # lightweight: 19 seeds slightly above the reference, one far below -> mean negative, test driven by the 19
    fab("lightweight", [rr + 0.002] * 19 + [rr - 0.2]); fab("cnn_lstm", [rr - 0.01 - 0.001 * i for i in range(20)])
    run(d, "stb_stats.py"); S = json.load(open(f"{d}/stb_summary.json"))["primary_obs"]["models"]
    L_ = S["lightweight"]                                                                   # mean and signed ranks disagree
    assert L_["delta_mean"] < 0 and L_["p_delta"] > 0.5 and L_["outcome_delta"] == "inconclusive", L_["outcome_delta"]
    assert L_["delta_secondary"]["hodges_lehmann"] > 0 and L_["delta_secondary"]["p_wilcoxon"] < 0.025     # reported, decides nothing
    assert S["cnn_lstm"]["outcome_delta"] == "negative" and S["cnn_lstm"]["outcome_net"] == "negative"
    # incomplete: one seed fails the receiver check -> descriptives reported, outcome inconclusive
    fab("cnn_lstm", [rr - 0.01] * 20, valid=[True] * 19 + [False])
    run(d, "stb_stats.py"); S = json.load(open(f"{d}/stb_summary.json"))["primary_obs"]["models"]["cnn_lstm"]
    assert S["status"] == "incomplete" and S["seeds_invalid_receiver"] == [19] and "delta_mean" in S and S["outcome_net"].startswith("inconclusive")
    os.remove(f"{d}/runs/stb_obs_cnn_lstm_s7.json")                                         # a seed with no result at all
    run(d, "stb_stats.py"); S = json.load(open(f"{d}/stb_summary.json"))["primary_obs"]["models"]["cnn_lstm"]
    assert S["seeds_missing"] == [7] and S["status"] == "incomplete"
    # reference failing the receiver check -> every comparison invalid
    C["test"][C["selected"]]["receiver_verified"] = False; json.dump(C, open(f"{d}/stb_obs_cheap.json", "w"))
    run(d, "stb_stats.py"); J = json.load(open(f"{d}/stb_summary.json")); S = J["primary_obs"]["models"]
    assert all(v["status"].startswith("invalid") for v in S.values())
    assert all(J["predictions"][k] == "invalid" for k in ("H1_cnn_lstm_net_negative", "H2_lightweight_delta_negative", "H3_lightweight_net_negative"))
    st = [x["station"] for x in S["cnn_lstm"]["per_station_descriptive"]["stations"]]
    assert st == json.load(open(f"{d}/stb_meta.json"))["stations_kept"]                    # stations without test steps are listed

if __name__ == "__main__":
    d = check_main(); print("main synthetic archive: OK")
    check_tiny(); print("not-evaluable archive: OK")
    check_stats(d); print("statistics rules: OK")
    print("ALL SYNTHETIC CHECKS PASSED")
