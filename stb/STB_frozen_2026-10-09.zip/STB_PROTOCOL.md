# Protocol: evaluation on an archived sensor deployment not analysed during development

Version 4, 9 October 2026. It is frozen when this file and its SHA-256 are sent in a dated message
(WhatsApp) from the first author (O. Alani) to the co-author (M. M. Jaber); no measurement or timestamp
of the deployment is read before that message. After freezing, nothing in this file, the code listed in section 9 or the data
selection changes before the results are reported. A necessary change is made only as a dated
amendment appended to this file, stating the reason and the results affected. A bug is code that does
not do what this protocol says; a bug-fix rerun uses the same seeds and settings, and the invalidated
outputs are kept. Every result is reported as it comes out, whichever way it points.

## 1. Purpose

The main study is a retrospective benchmark: its recordings were examined during development and the
alpha and K grids were widened after test-span results had been seen (Section 7.1). This protocol
tests, on one physical sensor deployment that the authors have not analysed, whether the Intel pattern
holds against the validation-selected low-cost reference: the lightweight network suppresses less, and
both learned models have higher modelled energy. It provides evidence from one additional deployment,
not from 23 independent deployments.

## 2. Data, selection and exposure

Source: SensorScope archive, Zenodo, DOI 10.5281/zenodo.2654726 (CC BY 4.0), file Sensorscope.zip,
MD5 4bbed2bbd48e535bc2877cad339fbbd6 (verified on the download, 9 October 2026). Selected file:
stbernard-meteo.zip, SHA-256 2a78ee47f6bc8bab893d1db99ea33aad6b12682a50ee6796379d524464d5f9de
(computed on the file as extracted from the archive, before it was opened; checked again by the first
command of section 7).

Deployments in the archive, by number of station files in the meteorological archives: LUCE 97,
Grand St Bernard 23, Le Genepi 16, Plaine Morte 13, PDG 2008 10, Fishnet 6.

Selection, stated as it happened: the deployment was chosen after the archive inventory (file names and
sizes) had been seen; it is not a rule fixed before that inventory. LUCE was excluded for the compute
budget, and Grand St Bernard is the largest remaining deployment by station count. The co-author
approved the selection on 9 October 2026. A subset of LUCE stations was not used because it would need
further choices (which stations, which period) made after the inventory had been seen.

Compute estimate (metadata and pipeline timings only, an estimate): the LUCE meteorological files total
3,822 MB, 72 times the 53.3 MB of Grand St Bernard. Assuming about 100 bytes per reading (17 numeric
columns), LUCE holds about 38 million readings and Grand St Bernard about 0.5 million. On the Intel
observed-only preparation (about 0.29 million validation and test steps) this pipeline takes about 65 s
per lightweight seed and 220 s per CNN-LSTM seed. Scaled by validation and test steps, both learned models
with twenty seeds on both preparations would need of the order of 200 single-core hours for LUCE and a
few hours for Grand St Bernard.

Exposure: before freezing, the authors read only the archive's MD5, the names and sizes of the files in
it and in its inner archives, stbernard-meteo-def.txt (column definitions), station_gsb_XY.txt (station
coordinates), the SHA-256 of stbernard-meteo.zip and the Zenodo record page; only these informed the
selection. No measurement and no timestamp of any SensorScope deployment was opened; the station map
GSB_Stations.pdf was not used. The authors have never analysed SensorScope data (search of every earlier
manuscript and code version). The deployment has been used in published studies, some of which the
authors may have read.

Manifest of stbernard-meteo.zip (archive listing): 24 entries, stbernard-meteo-def.txt and one file per
station, stations 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 20, 25, 28, 29, 31, 32;
53,337,349 bytes uncompressed in total. station_gsb_XY.txt lists the same 23 stations. The station files
present in the zip are the candidates; stb_meta.json records them and any difference from this list.

Variables (stbernard-meteo-def.txt): column 1, station id; column 8, time since the epoch [s] (UTC);
column 9, ambient temperature [degC].

## 3. Preparation (stb_prepare.py; all steps automatic)

1. Parsing, in file order, before the period, D and the boundaries are computed: a line is used only
   if it has exactly 17 fields, field 1 equals the station number of its file, and fields 8 and 9 are
   finite numbers. Other lines (headers, short, long or shifted rows) are dropped and counted, with a
   histogram of field counts. Timestamps outside 1 January 2005 to 1 January 2011 UTC (missing values,
   a wrong unit such as milliseconds, or dates far from the SensorScope deployments of 2006 to 2008)
   are dropped and counted. A reading more than 1 hour earlier than the latest timestamp already
   accepted from the same file (a device clock reset) is dropped and counted, unless this would drop
   more than 5% of the file's lines; the file is then taken as not written in time order, the rule is
   not applied to it, and this is reported. Readings with an ambient temperature outside the open
   interval (-50, 50) degC are dropped and counted. No other cleaning is done: values inside that interval are kept even if they look like
   sensor faults, and the number of readings more than 5 degC from both neighbours is reported.
   The readings are then sorted by time, and readings of one station with the same timestamp are
   averaged and counted.
2. Period: a station counts on a UTC calendar day if it has at least 12 readings on it, and a day
   qualifies if at least half of the candidate stations (12 of 23) count on it. Qualifying days are
   joined into runs, a gap of at most 2 non-qualifying days being bridged (an outage of up to two days
   therefore stays inside the period, where the segment rule cuts it); the period is the run spanning
   the most days (ties: more station-days, then the earlier run), from the start of its first day to
   the start of the day after its last (excluded). Readings outside it are dropped and counted. Stray
   timestamps and sparse tails (fewer than 12 readings a day) cannot stretch it; a longer outage of
   most stations splits the record, and only the longer part is used.
3. Nominal interval D: the median over candidate stations of each station's median positive interval
   between consecutive readings within the period, rounded half up to whole seconds (not evaluable if
   D < 1 s); a station with fewer than two readings in the period does not enter the median. The same D
   is used for every station: a station sampling at more than about twice D fails rule 5, and one
   unusually fast station changes D little (by one rank of the median).
4. Calendar boundaries, common to all stations and fixed before eligibility and before any filling:
   training = first 50% of the period's elapsed time, validation = next 20%, test = last 30%.
5. Eligibility, from the training span only (the later spans play no part): the station's training
   readings are cut into segments as in rule 6; a station is kept if it has at least one training
   segment longer than 12 readings and, pooled over those segments, its readings occupy at least 50% of
   the D-wide bins they span (gaps between segments are not counted, so a stray reading or burst away
   from the station's other data does not exclude it). A kept station with no readings in a later span
   simply contributes nothing there; per-station coverage is reported.
6. Segments: each kept station's readings in each span, cut at each calendar boundary and wherever the
   elapsed time between consecutive readings exceeds 10 D (the Intel analysis used 300 s, about ten
   31-second periods). No reading, window, interpolation or predictor history crosses a cut.
7. Primary preparation P_obs: the observed readings of each segment.
   Secondary preparation P_fill (sensitivity only): bins of width D from the segment's first reading
   (bin k covers [t0 + kD, t0 + (k+1)D)); a bin's value is the mean of the readings in it and its time
   their mean time, and the number of readings per bin is kept; an empty bin gets the linear
   interpolation, in elapsed time at its centre, of the neighbouring occupied bins. The first and last
   bins of a segment always hold readings, so there is no leading or trailing filling and no
   interpolation outside two observed endpoints of one segment.
8. Short segments: a segment of at most 12 readings has no prediction step. Its readings are sent as
   initialisation reports and are counted in total energy and coverage, but not in any suppression or
   error denominator. In every segment the first 12 readings are initialisation reports.
9. Feasibility, for P_obs and P_fill independently: a preparation is evaluable only if at least one
   station is kept, the training segments give at least 1,000 windows, and validation and test each
   have at least 1,000 prediction steps. Otherwise it is reported as not evaluable, nothing is run on
   it, and no other deployment or threshold is substituted.

## 4. Predictors, selection and evaluation (as in the main study)

Tolerance tau = 0.10 degC, physical, as for Intel. Low-cost arms: persistence (0 MACs), exponential
smoothing (12 MACs, alpha from ALPHA_GRID) and linear extrapolation (K MACs, K from LIN_K_GRID), each
selected on validation suppression; the low-cost reference is the arm with the highest validation
suppression (ties: smaller alpha, smaller K; then persistence, smoothing, extrapolation). Learned models:
the lightweight network (208 MACs) and the CNN-LSTM (99,488 MACs), one model shared by all stations,
trained on at most 4,000 windows of the training segments (sampled with rng seed 0; Keras holds out
15% of them for its loss curve, as in the main study), standardised with training-window statistics,
seeds 0-19, checkpoints every 25 epochs up to 200, checkpoint selected on validation suppression, Keras
equivalence of the fast forward pass checked at every checkpoint. CNN-LSTM training is not bitwise
deterministic, so its results are reproducible in distribution across seeds.

Pooling: every suppression used for selection or reporting is pooled over all prediction steps of all
segments of the span (1 - transmissions / steps), not a mean of station rates.

Every test run is checked by an independent receiver that rebuilds every segment from the transmitted
packets alone with its own predictor object; the run is valid only if sender and receiver agree and no
reconstruction error exceeds tau. Evaluation code: segeval.py, which reproduces the evaluator of the
main study on the published Intel matrix (test_segeval.py, section 8).

## 5. Analysis

Primary: P_obs at e_r = 3.8e-4 J per report and E_op = 1 nJ per MAC. For each learned model and seed:
dd = test suppression minus the reference's test suppression, and g = e_r dd - (MACs_model -
MACs_reference) E_op, the net saving per scored prediction step (the initialisation reports are the
same for every arm and cancel from g; they are included in the total energy and in the lifetime ratio,
both reported).

Estimand: the mean over training seeds of dd and of g, that is the expected difference in suppression
and in modelled energy over training randomness on this deployment. Test: an exact two-sided sign-flip
permutation test of that mean over the 20 seeds (all 2^20 sign assignments of the per-seed differences;
p is the share of assignments whose absolute mean is at least the observed one, with a relative
tolerance of 1e-12; the smallest attainable p is about 1.9e-6); p = 1 if all differences are zero. The
test, the estimate and the direction of a significant result (the sign of the mean) therefore answer
the same question. The main study used the Wilcoxon signed-rank test, whose effect is a location shift
of the signed ranks rather than the mean; for comparison its p-value (scipy 1.17.1 defaults) and the
Hodges-Lehmann estimate are reported here as secondary statistics that decide nothing.

Family, fixed now: 2 models x 1 deployment, one family for dd and one for g; Bonferroni threshold
0.05 / 2 = 0.025 in each. It does not shrink if runs fail.

Outcome of each comparison, one of three: significantly positive mean (evidence for the learned
model), significantly negative mean (evidence for the reference), or inconclusive. An inconclusive energy result is not evidence that the learned model costs more;
keeping the low-cost reference in that case is a decision policy, reported as such.

Scope of the test: the reference is fixed and the 20 seeds vary only the training of the learned model,
so the test and the seed-bootstrap intervals measure training randomness on this fixed deployment, not
uncertainty across periods, stations or deployments; with 20 seeds even a small consistent difference
is significant. Effect sizes (mean with a 95% percentile bootstrap interval over seeds, 10,000
resamples, rng seed 0) are reported next to every p-value, and significance is not used
to claim generalisation.

Predictions, from the Intel results of the main study:
- H1: the CNN-LSTM net saving is significantly negative.
- H2: the lightweight network's dd is significantly negative (it suppresses less than the reference).
- H3: the lightweight network's net saving is significantly negative.
Each is reported as confirmed, failed (the opposite significant result), inconclusive, or invalid (if
the comparison is invalid). H1 and H3 are close to settled by the arithmetic: the CNN-LSTM breaks even
only if dd >= 0.262 (99,488 nJ / 3.8e-4 J), and the lightweight network at dd of about 5.5e-4, so H3
nearly coincides with H2. H2 is the prediction with real uncertainty, and the three are not presented
as independent confirmations. The CNN-LSTM's dd is reported with the same test, without a prediction.

Descriptive, without significance claims: per-station dd and g for every kept station (mean over seeds;
median and interquartile range across stations with test steps; stations without test steps listed);
the three equal-duration chronological blocks of the test span, formed by partitioning the existing
test predictions (predictor state continues across block boundaries; nothing is rerun); coverage per
span and station; parsing and cleaning counts; total energy and lifetime ratio including initialisation.

Secondary, descriptive (labels shown but not counted as tests): the same analysis on P_fill; net savings
at the four GAP-8 values of Section 6.6 (16-bit weight transfer over 1e5 rounds); and P_obs against
P_fill on the test readings that are a single reading in a P_fill bin (suppression and errors; learned
models over the seeds valid in both). P_obs and P_fill have different prediction opportunities and
elapsed prediction intervals, so a difference between them is not attributed to interpolation alone.

## 6. Failures and integrity

- Each learned seed is attempted at most twice with the same seed: an exception is retried at once by
  stb_run.py, and a process that dies is started again by stb_driver.sh, which runs one seed per
  process; stb_run.py counts the attempts. After two failed attempts the seed is recorded as failed (or,
  if the process died both times, it has no result and is listed as missing), and the run continues
  with the next seed.
- A comparison with fewer than 20 valid seeds (failed, missing or invalid) is reported as incomplete:
  its descriptive statistics are shown and its outcome is inconclusive; the family is not reduced.
- A failed receiver check makes a run invalid: it is logged and investigated, and its result is not used
  as a bounded-error result. If the selected low-cost reference fails the check, every comparison and
  prediction is reported as invalid.
- The low-cost run of a preparation is started at most twice (stb_driver.sh); if both fail, that
  preparation is reported as not run, without results.
- A process that hangs is stopped by hand after 24 hours and counted as a failed attempt; this is logged.
- No learned model is retrained, retuned or re-seeded after test results have been seen, except a
  bug-fix rerun as described in the preamble.

## 7. Commands (run directory holding the files of section 9 and stbernard-meteo.zip)

    echo "2a78ee47f6bc8bab893d1db99ea33aad6b12682a50ee6796379d524464d5f9de  stbernard-meteo.zip" | sha256sum -c
    sha256sum -c STB_FROZEN.sha256                       # the files of section 9
    python3 test_segeval.py                              # evaluator check on the Intel matrix
    python3 stb_synthetic_check.py                       # synthetic-data check (no real data)
    python3 stb_prepare.py stbernard-meteo.zip           # -> stb_meta.json, stb_segments_{obs,fill}.pkl
    bash stb_driver.sh A & bash stb_driver.sh B; wait    # -> stb_*_cheap.json, runs/, cells/, weights_stb/
    python3 stb_stats.py                                 # -> stb_summary.json

## 8. Checks made before freezing

test_segeval.py passes: on the published Intel matrix, with every column of the validation and test
spans as one segment, segeval.py gives the same transmission decisions as the evaluator of the main
study for the three low-cost arms, error statistics equal to within 1e-10, the shipped test suppression
of the seed-0 lightweight and CNN-LSTM weights (0.9008268, 0.8991201), and a passing receiver check.

stb_synthetic_check.py passes, on generated data only. It builds archives in the SensorScope file
format with: a header line, short and 18-field rows, CRLF line ends, 'nan', implausible values (999,
-60), a duplicate timestamp, a stray reading on 1 January 1970 and one in milliseconds in every station,
one 25 days after the end, a 20-reading clock reset, a file not written in time order, a stray reading before a station's real start, an outage of every station over a whole UTC day, short and long gaps, a 5-reading isolated
segment, a sparse station, a station sampling at 300 s, and a station absent from the later spans; and
a second, too small archive. It checks: the parsing counts, the period (stray days excluded, the outage day bridged), the manifest comparison, the 50/20/30 boundaries,
eligibility, that no segment crosses a boundary or a long gap, that P_fill fills only between observed
bins, the short-segment count, that segeval.py gives the same transmissions as the main-study evaluator
segment by segment for three predictors, a real lightweight seed with a passing receiver check, the
per-seed retry, failure and process-death records, the not-evaluable path, a case in which the mean
and the signed ranks point in opposite directions (the permutation test of the mean is inconclusive,
p = 1, while the secondary Wilcoxon test would call it positive), and the incomplete, missing-seed and
invalid-reference outcomes.

## 9. Frozen files (SHA-256)

| File | SHA-256 |
|---|---|
| stb_prepare.py | 901f738ee3456f5537825002fb324f8a92cdf6b2d7417283e5415a32d1e4acc8 |
| stb_run.py | f0fb79fcab31c833d0d272ebb1d70e27159c7de087759d7c882a1818a89cc5c1 |
| stb_stats.py | aea62edb8cfe5f36045be3a36cbf449ed7cefb45618d4cee8f54c38a694f92ca |
| stb_driver.sh | 0083f947c68cc68d39bab7f1570c1c11d2c1c9e2e9fe8dcd46e80e65c933b62f |
| stb_synthetic_check.py | 263c0bd8df87da3b5864ebebf46c38089cf398a804732c41bbf7f9f3b1be8632 |
| segeval.py | 36a9f6a5f9f29b00ad8b7971910982f339d53af0df752e7b4c60c9ee018fd07f |
| test_segeval.py | f3e68b8c809176e3583a92bebbe5a6094ce5bc217d36ab513591eeced1522f3f |
| frozen_benchmark.py | 1bf24e98c9f65e87b1c37e4925ba35d815cc98a76f579b15a65eb7b86117ac47 |
| fastfwd.py | c52d7d5a5d3f6847f56a5a8daf3fa6b46525241e0b86842693d73e71dcc13055 |
| dual_prediction_fix.py | e8cfb5f685df10023bc3d18e63ef850da0453008f74ac5a0d5653a019dd0f4d6 |
| platform_energy.py | 06f6a2354c9d7ae9bf9e3d8326c4ad30f0153d79610f12f4b4b1cab9ad3b0f2a |
| gap8_lstm_energy.py | f0f4b862e338b3d6cadbb13407373bd74f884cad9358b674fad872efb1ee8043 |
| ms_numbers.json | e9d4b9652b8938acbdbbb5a95415f7e2fba5debaf6ea63b16692145dc35d03ed |
| intel_time.npy | 88c0472c3d3b1184fb56bbb3888e8330c530963d5f97e2c56d61c087224782b3 |
| learned_intel_time.json | 6096f6d8fb2f0ab68d17fc7aab3f8aeaa785cf7d92013d43e114a0078f257698 |
| weights/intel_time_lightweight_s0.npz | 1db6f2be606c8dfeff8d7941fa99d960df6490bba3c1fd97f7e4c166cb4da170 |
| weights/intel_time_cnn_lstm_s0.npz | 8e0eef2a196234a52693662c65273aeb70956215a0c84800c7b8a8a1531ca1f7 |
| stbernard-meteo-def.txt | 43e0439706a6f11f670266b40c4a7badc42b134e911e1dc10e63c75917aafdfc |
| station_gsb_XY.txt | c4c3d4744e086ea86c22d855a4523d6cb5e295af02757eba8724c6e341d61d2e |
| inner_listing.txt | 7578aebf49aa37260cb017d06ac162c93142bb8f1d18dcdcb7151638bf23187d |

frozen_benchmark.py, fastfwd.py, dual_prediction_fix.py, platform_energy.py, gap8_lstm_energy.py, ms_numbers.json,
intel_time.npy, learned_intel_time.json and the two weight files are unchanged files of reproducibility package
v1.4 (main study; the last four are used only by test_segeval.py). stbernard-meteo-def.txt, station_gsb_XY.txt
and inner_listing.txt are the metadata read before freezing. The other files are new. The same list is in
STB_FROZEN.sha256.


Environment: Python 3.11, numpy 2.4.4, scipy 1.17.1, pandas 3.0.2, tensorflow-cpu 2.21.0, keras 3.15.1.
