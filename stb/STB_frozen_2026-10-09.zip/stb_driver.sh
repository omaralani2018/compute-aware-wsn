# Grand St Bernard run (STB_PROTOCOL.md, section 7). Two processes, one per CPU core; one learned seed per
# Python process, each started at most twice (stb_run.py counts the attempts and records a seed as failed
# after two); every seed is written to its own file.
#   bash stb_driver.sh A : low-cost arms (both preparations), lightweight (both), CNN-LSTM P_fill seeds 10-19
#   bash stb_driver.sh B : CNN-LSTM P_obs seeds 0-19, CNN-LSTM P_fill seeds 0-9
export PYTHONDONTWRITEBYTECODE=1
seeds() { for s in $(seq $3 $(($4 - 1))); do python3 stb_run.py $1 $2 $s $((s + 1)) || python3 stb_run.py $1 $2 $s $((s + 1)); done; }
if [ "$1" = A ]; then
  python3 stb_run.py obs cheap || python3 stb_run.py obs cheap
  python3 stb_run.py fill cheap || python3 stb_run.py fill cheap
  seeds obs lightweight 0 20
  seeds fill lightweight 0 20
  seeds fill cnn_lstm 10 20
else
  seeds obs cnn_lstm 0 20
  seeds fill cnn_lstm 0 10
fi
