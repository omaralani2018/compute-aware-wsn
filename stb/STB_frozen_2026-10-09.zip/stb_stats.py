"""Analysis of the Grand St Bernard run (STB_PROTOCOL.md, section 5). Writes stb_summary.json.
Usage: python3 stb_stats.py   (in the run directory, after stb_prepare.py and stb_run.py)

Estimand: the mean over training seeds of dd (suppression difference) and of g (net saving per scored
step), i.e. the expected difference over training randomness on this deployment. Test: exact two-sided
sign-flip permutation test of that mean (all 2^n sign assignments of the n per-seed differences;
p = share of assignments whose |mean| is at least the observed |mean|, with a relative tolerance of
1e-12); p = 1 if every difference is zero. The direction of a significant result is the sign of the
mean, so the test, the estimate and the direction answer the same question. For comparison with the
main study (which used the Wilcoxon signed-rank test), the Wilcoxon p-value (scipy 1.17.1 defaults) and
the Hodges-Lehmann estimate are also reported, as secondary statistics that decide nothing."""
import json, os, glob, numpy as np
from scipy.stats import wilcoxon
import frozen_benchmark as fb
from platform_energy import E_ELEC, PARAMS, REF_PARAMS
from gap8_lstm_energy import EOPS, H, BITS
E_R, E_OP, E_S, NSEED = fb.E_R, fb.E_OP, fb.E_SENSE, 20
MAC = {"lightweight": 208, "cnn_lstm": 99488}
THR = 0.05 / 2                                   # family fixed in the protocol: 2 models x 1 deployment, per test

def p_perm(x):
    x = np.asarray(x, float); n = len(x)
    if n == 0 or not np.any(x != 0): return 1.0
    signs = ((np.arange(2 ** n)[:, None] >> np.arange(n)) & 1) * 2.0 - 1.0
    sums = np.abs(signs @ x); obs = abs(x.sum())
    return float(np.mean(sums >= obs * (1 - 1e-12)))
def p_wilcoxon(x): return float(wilcoxon(x)[1]) if np.any(x != 0) else 1.0
def hodges_lehmann(x):
    i, j = np.triu_indices(len(x)); return float(np.median((x[i] + x[j]) / 2))
def outcome(x, p):
    if p >= THR or x.mean() == 0: return "inconclusive"
    return "positive" if x.mean() > 0 else "negative"
def boot(x, B=10000):
    rng = np.random.default_rng(0); i = rng.integers(0, len(x), (B, len(x))); m = x[i].mean(1)
    return [float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))]
def total_energy(macs, rho, n_steps, n_init):        # test span, J; initialisation reports: sensing + transmission
    return n_steps * (E_S + macs * E_OP + (1 - rho) * E_R) + n_init * (E_S + E_R)

def runs(prep, m):
    R = [json.load(open(f)) for f in glob.glob(f"runs/stb_{prep}_{m}_s*.json")]
    return sorted([r for r in R if 0 <= r["seed"] < NSEED], key=lambda r: r["seed"])

def analyse(prep, primary):
    C = json.load(open(f"stb_{prep}_cheap.json")); sel = C["selected"]; ref = C["test"][sel]
    rr, rm = ref["rho"], C["selected_macs"]
    I = np.load(f"cells/stb_{prep}_index.npz"); closed = ~I["warmup"]
    ref_sent = np.load(f"cells/stb_{prep}_{sel}.npz")["sent"]
    meta = json.load(open("stb_meta.json")); b2, P1 = meta["boundaries_epoch_s"][2], meta["boundaries_epoch_s"][3]
    edges = np.linspace(b2, P1, 4); block = np.clip(np.searchsorted(edges, I["bin"], side="right") - 1, 0, 2)
    stations = meta["stations_kept"]                  # every kept station is listed, with or without test steps
    E_ref = total_energy(rm, rr, ref["n_steps"], ref["n_init_reports"])
    out = dict(analysis="primary" if primary else "secondary, descriptive", reference=sel, reference_macs=rm, reference_rho=rr,
               alpha=C["alpha"], K=C["K"], low_cost_test={n: {k: t[k] for k in ("rho", "rho_incl_init", "mean_err", "rmse", "max_err",
               "n_steps", "n_init_reports", "receiver_verified")} for n, t in C["test"].items()},
               reference_energy_test_J=E_ref, coverage=meta["preparations"][prep], models={})
    ref_valid = bool(ref["receiver_verified"])
    def rho_mask(sent, mk): return 1.0 - sent[mk].sum() / mk.sum() if mk.sum() else float("nan")
    for m in MAC:
        E = runs(prep, m); ok = [r for r in E if r["status"] == "ok"]; valid = [r for r in ok if r["receiver_verified"]]
        R = dict(seeds_run=[r["seed"] for r in E], seeds_failed=[r["seed"] for r in E if r["status"] != "ok"],
                 seeds_missing=[s for s in range(NSEED) if s not in {r["seed"] for r in E}],
                 seeds_invalid_receiver=[r["seed"] for r in ok if not r["receiver_verified"]], n_valid=len(valid))
        if not ref_valid: R["status"] = "invalid (reference failed the receiver check)"
        elif len(valid) < NSEED: R["status"] = "incomplete"
        else: R["status"] = "complete"
        if valid:
            v = np.array([r["test_rho"] for r in valid]); dd = v - rr; dE = (MAC[m] - rm) * E_OP; g = E_R * dd - dE
            Em = np.array([total_energy(MAC[m], r["test_rho"], r["test_n_steps"], r["test_n_init_reports"]) for r in valid])
            R.update(rho_mean=float(v.mean()), rho_sd=float(v.std()), mean_err=float(np.mean([r["test_mean_err"] for r in valid])),
                     rmse=float(np.mean([r["test_rmse"] for r in valid])), max_err=float(np.max([r["test_max_err"] for r in valid])),
                     delta_mean=float(dd.mean()), delta_ci95=boot(dd), p_delta=p_perm(dd),
                     delta_secondary=dict(hodges_lehmann=hodges_lehmann(dd), p_wilcoxon=p_wilcoxon(dd)),
                     net_saving_per_scored_step_uJ_mean=float(g.mean() * 1e6), net_saving_ci95_uJ=[x * 1e6 for x in boot(g)], p_net=p_perm(g),
                     net_secondary=dict(hodges_lehmann_uJ=hodges_lehmann(g) * 1e6, p_wilcoxon=p_wilcoxon(g)),
                     total_energy_test_J_mean=float(Em.mean()), lifetime_ratio_incl_init_mean=float(np.mean(E_ref / Em)),
                     crossover_er=(float(dE / dd.mean()) if dd.mean() > 0 else None))
            complete = R["status"] == "complete"
            R["outcome_delta"] = outcome(dd, R["p_delta"]) if complete else "inconclusive (" + R["status"] + ")"
            R["outcome_net"] = outcome(g, R["p_net"]) if complete else "inconclusive (" + R["status"] + ")"
            S = np.array([np.load(f"cells/stb_{prep}_{m}_s{r['seed']}.npz")["sent"] for r in valid])
            per_st = []
            for st in stations:
                mk = closed & (I["mote"] == st)
                if mk.sum() == 0: per_st.append(dict(station=int(st), steps=0)); continue
                d = float(np.mean([rho_mask(s, mk) for s in S]) - rho_mask(ref_sent, mk))
                per_st.append(dict(station=int(st), steps=int(mk.sum()), delta=d, net_saving_uJ=(E_R * d - dE) * 1e6))
            ds = np.array([x["delta"] for x in per_st if x["steps"] > 0])
            R["per_station_descriptive"] = dict(stations=per_st, n_with_test_steps=int(len(ds)),
                delta_median=float(np.median(ds)) if len(ds) else None,
                delta_iqr=[float(np.percentile(ds, 25)), float(np.percentile(ds, 75))] if len(ds) else None,
                n_delta_positive=int((ds > 0).sum()))
            R["per_block_descriptive"] = []
            for b in range(3):
                mk = closed & (block == b)
                d = float(np.mean([rho_mask(s, mk) for s in S]) - rho_mask(ref_sent, mk)) if mk.sum() else None
                R["per_block_descriptive"].append(dict(block=b + 1, steps=int(mk.sum()), delta=d,
                                                       net_saving_uJ=((E_R * d - dE) * 1e6) if d is not None else None))
            R["gap8_secondary_descriptive"] = {}
            for eop in EOPS:
                Emx = MAC[m] * eop + (PARAMS[m] - REF_PARAMS[sel]) * BITS * E_ELEC / H; gg = E_R * dd - (Emx - rm * eop)
                R["gap8_secondary_descriptive"][f"{eop*1e9:.4f}"] = dict(net_saving_uJ_mean=float(gg.mean() * 1e6), p=p_perm(gg),
                                                                          label=outcome(gg, p_perm(gg)) if complete else "n/a")
        else:
            R["outcome_delta"] = R["outcome_net"] = "inconclusive (" + R["status"] + ", no valid seed)"
        if not primary:
            R["descriptive_label_delta"] = R.pop("outcome_delta"); R["descriptive_label_net"] = R.pop("outcome_net")
        out["models"][m] = R
    return out

def observed_point_comparison():
    """P_obs and P_fill on the test readings that are single readings in both (secondary, descriptive)."""
    if not (os.path.exists("cells/stb_fill_index.npz") and os.path.exists("cells/stb_obs_index.npz")): return None
    A, B = np.load("cells/stb_obs_index.npz"), np.load("cells/stb_fill_index.npz")
    ka = {(int(m), float(t)): i for i, (m, t, w) in enumerate(zip(A["mote"], A["bin"], A["warmup"])) if not w}
    common = [(ka[(int(m), float(t))], j) for j, (m, t, c, w) in enumerate(zip(B["mote"], B["bin"], B["count"], B["warmup"]))
              if c == 1 and not w and (int(m), float(t)) in ka]           # P_fill bins holding exactly one reading
    if not common: return dict(common_points=0)
    ia, ib = np.array([c[0] for c in common]), np.array([c[1] for c in common])
    res = dict(common_points=int(len(common)), arms={})
    def summ(prep, idx, files):
        S = [np.load(f) for f in files]
        sent = np.mean([s["sent"][idx] for s in S], 0); err = np.mean([np.abs(s["err"][idx]) for s in S], 0)
        return dict(suppression=float(1 - sent.mean()), mae=float(err.mean()), max_err=float(err.max()))
    for arm in ("persistence", "expsm", "linear_extrap"):
        res["arms"][arm] = dict(obs=summ("obs", ia, [f"cells/stb_obs_{arm}.npz"]), fill=summ("fill", ib, [f"cells/stb_fill_{arm}.npz"]))
    for m in MAC:                                      # seeds valid in both preparations only
        so = {r["seed"] for r in runs("obs", m) if r["status"] == "ok" and r["receiver_verified"]}
        sf = {r["seed"] for r in runs("fill", m) if r["status"] == "ok" and r["receiver_verified"]}
        both = sorted(so & sf)
        if both: res["arms"][m] = dict(seeds=both, obs=summ("obs", ia, [f"cells/stb_obs_{m}_s{x}.npz" for x in both]),
                                       fill=summ("fill", ib, [f"cells/stb_fill_{m}_s{x}.npz" for x in both]))
    return res

if __name__ == "__main__":
    meta = json.load(open("stb_meta.json"))
    res = {"protocol": "STB_PROTOCOL.md", "threshold": THR, "evaluable": meta.get("evaluable"), "not_evaluable_reason": meta.get("not_evaluable_reason")}
    if not meta["evaluable"].get("obs"): res["primary_obs"] = "not evaluable"
    elif not os.path.exists("stb_obs_cheap.json"): res["primary_obs"] = "not run: the low-cost arms failed twice"
    else: res["primary_obs"] = analyse("obs", True)
    if meta["evaluable"].get("fill") and os.path.exists("stb_fill_cheap.json"): res["secondary_fill"] = analyse("fill", False)
    res["secondary_observed_points"] = observed_point_comparison()
    if isinstance(res["primary_obs"], dict):
        P = res["primary_obs"]["models"]
        def pred(m, o, want):
            if P[m]["status"].startswith("invalid"): return "invalid"
            return "confirmed" if o == want else ("failed" if o in ("positive", "negative") else "inconclusive")
        res["predictions"] = dict(H1_cnn_lstm_net_negative=pred("cnn_lstm", P["cnn_lstm"]["outcome_net"], "negative"),
                                  H2_lightweight_delta_negative=pred("lightweight", P["lightweight"]["outcome_delta"], "negative"),
                                  H3_lightweight_net_negative=pred("lightweight", P["lightweight"]["outcome_net"], "negative"),
                                  cnn_lstm_delta_no_prediction=P["cnn_lstm"]["outcome_delta"])
    else: res["predictions"] = "not evaluable"
    json.dump(res, open("stb_summary.json", "w"), indent=1)
    print(json.dumps(res["predictions"], indent=1))
